-- H3 Tarea 3 - Consultas SELECT
-- Sistema de videovigilancia inteligente - El Alto

-- SELECT 1: consultar las conductas sospechosas detectadas
-- junto con la cámara y el local donde ocurrieron.
SELECT
    e.id_evento,
    e.fecha_hora,
    e.tipo_conducta,
    e.nivel_confianza,
    c.nombre AS camara,
    l.nombre AS local
FROM evento e
INNER JOIN camara c ON e.id_camara = c.id_camara
INNER JOIN local l ON c.id_local = l.id_local
WHERE e.tipo_conducta = 'SOSPECHOSA'
ORDER BY e.fecha_hora DESC;

-- SELECT 2: consultar las alertas pendientes que deben ser atendidas
-- por el usuario, mostrando la conducta detectada.
SELECT
    a.id_alerta,
    a.fecha_hora,
    a.estado AS estado_alerta,
    u.nombre AS usuario,
    e.tipo_conducta,
    e.nivel_confianza
FROM alerta a
INNER JOIN evento e ON a.id_evento = e.id_evento
LEFT JOIN usuario u ON a.id_usuario = u.id_usuario
WHERE a.estado = 'PENDIENTE'
ORDER BY a.fecha_hora DESC;
