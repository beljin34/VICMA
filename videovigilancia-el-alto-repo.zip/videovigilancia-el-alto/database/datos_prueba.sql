-- Datos de prueba para verificar las consultas SELECT
INSERT INTO usuario (nombre, usuario, contrasena, rol) VALUES
 ('Isabel Condori', 'icondori', 'hash_demo_1', 'PROPIETARIO');
INSERT INTO local (nombre, direccion) VALUES
 ('Minimarket Los Andes', 'Av. 6 de Marzo, Zona Villa Dolores');
INSERT INTO camara (id_local, nombre, direccion_ip, puerto, url_rtsp) VALUES
 (1, 'Camara Pasillo 1', '192.168.1.20', 554, 'rtsp://192.168.1.20:554/stream1'),
 (1, 'Camara Caja', '192.168.1.21', 554, 'rtsp://192.168.1.21:554/stream1');
INSERT INTO evento (id_camara, tipo_conducta, nivel_confianza, tiempo_permanencia, distancia_recorrida) VALUES
 (1, 'SOSPECHOSA', 91.50, 48.20, 12.40),
 (1, 'NORMAL',     97.10,  6.00,  3.10),
 (2, 'SOSPECHOSA', 84.30, 35.00,  5.60);
INSERT INTO alerta (id_evento, id_usuario, tipo, estado) VALUES
 (1, 1, 'VISUAL', 'PENDIENTE'),
 (3, 1, 'SONORA', 'ATENDIDA');
INSERT INTO evidencia (id_evento, ruta_archivo, tipo_archivo) VALUES
 (1, '/evidencias/evento_1.mp4', 'VIDEO'),
 (1, '/evidencias/evento_1.jpg', 'IMAGEN');
