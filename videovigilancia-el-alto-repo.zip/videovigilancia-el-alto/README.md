# Sistema de videovigilancia inteligente - El Alto

Proyecto Integrador II - Universidad Franz Tamayo, Ingeniería de Sistemas.

Sistema web de videovigilancia con visión por computadora y aprendizaje
automático para detectar en tiempo real conductas sospechosas en comercios
de El Alto y alertar al propietario.

**Estudiante:** Isabel Condori Caballero
**Docente:** Ing. Juan Gabriel Lazcano Balanza

## Flujo de ramas (Git Flow simplificado)

| Rama | Propósito |
|------|-----------|
| `main` | Versión estable / entregable |
| `develop` | Integración de funcionalidades |
| `feature/*` | Una rama por funcionalidad, creada desde `develop` |
